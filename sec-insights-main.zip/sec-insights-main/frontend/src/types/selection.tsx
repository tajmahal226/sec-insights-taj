export interface SelectOption {
  value: string;
  label: string;
}
