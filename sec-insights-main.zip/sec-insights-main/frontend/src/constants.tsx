export const GOOGLE_ANALYTICS_ID = "G-LGHB46ZGWR";
export const INTERCOM_ID = "rx71g1uo";
// TODO: Populate with your own Sentry DSN:
// https://docs.sentry.io/product/sentry-basics/concepts/dsn-explainer/
export const SENTRY_DSN: string | undefined = undefined;
