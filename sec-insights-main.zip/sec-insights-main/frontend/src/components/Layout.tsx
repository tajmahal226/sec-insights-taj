import React from "react";
import type { PropsWithChildren } from "react";
const Layout = ({ children }: PropsWithChildren) => {
  return <>{children}</>;
};
export default Layout;
